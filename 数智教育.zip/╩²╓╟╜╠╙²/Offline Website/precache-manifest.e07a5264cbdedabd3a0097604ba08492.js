self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "0e4930d1cc7a19456c3d3039eb81596f",
    "url": "./index.html"
  },
  {
    "revision": "a88e0f485865ba297149",
    "url": "./static/css/2.45868043.chunk.css"
  },
  {
    "revision": "7b2e3fbb1b0202d3f9c5",
    "url": "./static/css/main.d6693b7b.chunk.css"
  },
  {
    "revision": "a88e0f485865ba297149",
    "url": "./static/js/2.3b8ca991.chunk.js"
  },
  {
    "revision": "7b2e3fbb1b0202d3f9c5",
    "url": "./static/js/main.a418d94d.chunk.js"
  },
  {
    "revision": "8c97409f0ee389fe75da",
    "url": "./static/js/runtime~main.d653cc00.js"
  },
  {
    "revision": "f6406778e92621cf3917f92702d78047",
    "url": "./static/media/app.f6406778.jpg"
  },
  {
    "revision": "e2aacd8c1bc6d92305f49b772f39b29c",
    "url": "./static/media/class.e2aacd8c.jpg"
  },
  {
    "revision": "ad4eb2987149780c2c92e9e2a2b71371",
    "url": "./static/media/school_score.ad4eb298.jpg"
  },
  {
    "revision": "9c4755a7e048d15362bd8e1081ec1f61",
    "url": "./static/media/student.9c4755a7.jpg"
  }
]);